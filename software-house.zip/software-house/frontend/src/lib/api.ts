// src/lib/api.ts — typed wrappers around the Hono backend

const BASE = import.meta.env.PUBLIC_API_URL ?? "";

export type Project = {
  id: number;
  slug: string;
  title: string;
  client: string;
  category: string;
  description: string;
  longDescription: string | null;
  techStack: string[];
  imageUrl: string | null;
  liveUrl: string | null;
  featured: boolean;
  sortOrder: number;
  createdAt: string;
};

export type Lead = {
  name: string;
  email: string;
  company?: string;
  budget?: string;
  message: string;
};

export async function getProjects(featured?: boolean): Promise<Project[]> {
  const url = featured ? `${BASE}/api/projects?featured=true` : `${BASE}/api/projects`;
  const res = await fetch(url);
  if (!res.ok) throw new Error("Failed to fetch projects");
  return res.json();
}

export async function getProject(slug: string): Promise<Project> {
  const res = await fetch(`${BASE}/api/projects/${slug}`);
  if (!res.ok) throw new Error("Project not found");
  return res.json();
}

export async function submitLead(lead: Lead): Promise<{ success: boolean; id: number }> {
  const res = await fetch(`${BASE}/api/leads`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(lead),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({})) as { error?: string };
    throw new Error(err.error ?? "Failed to submit");
  }
  return res.json();
}
