import { defineConfig } from "astro/config";

export default defineConfig({
  // Output static HTML + hydrate islands as needed
  output: "static",

  // Vite dev server config — proxy API calls to the local Worker
  vite: {
    server: {
      proxy: {
        "/api": {
          target: "http://localhost:8787",
          changeOrigin: true,
        },
      },
    },
    define: {
      // Expose the backend URL to client JS
      "import.meta.env.PUBLIC_API_URL": JSON.stringify(
        process.env.PUBLIC_API_URL ?? "http://localhost:8787"
      ),
    },
  },
});
