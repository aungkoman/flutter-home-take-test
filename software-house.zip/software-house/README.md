# Stratum — Software House Website

Full-stack agency portfolio: **Astro** frontend + **Hono** on **Cloudflare Workers** backend, with **Drizzle ORM → D1** for data and **R2** for media.

---

## Stack

| Layer | Technology |
|---|---|
| Frontend | Astro 4 (static output) |
| Backend | Hono 4 on Cloudflare Workers |
| Database | Cloudflare D1 (SQLite) via Drizzle ORM |
| File storage | Cloudflare R2 |
| Deploy | Wrangler CLI |

---

## Monorepo layout

```
software-house/
├── frontend/          # Astro site
│   ├── src/
│   │   ├── components/   # Nav, Hero, Work, Services, About, Contact, Footer
│   │   ├── layouts/      # Base.astro
│   │   ├── lib/          # Typed API client
│   │   ├── pages/        # index, /work, /work/[slug]
│   │   └── styles/       # global.css (design tokens)
│   └── astro.config.mjs
│
└── backend/           # Hono Worker
    ├── src/
    │   ├── db/           # Drizzle schema + D1 client
    │   ├── routes/       # leads.ts, projects.ts
    │   ├── middleware/   # cors.ts
    │   └── index.ts      # App entry point
    ├── drizzle/          # Migration SQL files
    ├── drizzle.config.ts
    └── wrangler.jsonc    # D1 + R2 bindings
```

---

## Quick start

### 1 — Prerequisites

```bash
npm install -g wrangler
wrangler login
```

### 2 — Create Cloudflare resources

```bash
# D1 database
wrangler d1 create software-house-db
# → Copy the database_id into backend/wrangler.jsonc

# R2 bucket
wrangler r2 bucket create software-house-assets
# Enable public access in the Cloudflare dashboard, then set R2_PUBLIC_URL in wrangler.jsonc
```

### 3 — Apply database migrations

```bash
cd backend
npm install

# Local (for dev):
npm run db:migrate:local

# Remote (production):
npm run db:migrate
```

### 4 — Start local development

```bash
# Terminal 1 — Worker (API)
cd backend && npm run dev       # http://localhost:8787

# Terminal 2 — Astro site
cd frontend && npm install && npm run dev  # http://localhost:4321
```

Astro's dev server proxies `/api/*` to the local Worker automatically.

### 5 — Deploy

```bash
# Deploy Worker first
cd backend && npm run deploy

# Build + deploy Astro (to Cloudflare Pages or any static host)
cd frontend
PUBLIC_API_URL=https://api.yourdomain.com npm run build
# Upload dist/ to Cloudflare Pages / Vercel / Netlify
```

---

## API reference

### Leads

| Method | Path | Description |
|---|---|---|
| `POST` | `/api/leads` | Submit contact form |
| `GET` | `/api/leads` | List all leads (admin) |
| `PATCH` | `/api/leads/:id/status` | Update lead status |

**POST `/api/leads` body:**
```json
{
  "name": "Alex Morgan",
  "email": "alex@company.com",
  "company": "Acme Inc.",        // optional
  "budget": "$30k–$80k",         // optional
  "message": "We need a SaaS..."
}
```

### Projects

| Method | Path | Description |
|---|---|---|
| `GET` | `/api/projects` | List all projects |
| `GET` | `/api/projects?featured=true` | List featured only |
| `GET` | `/api/projects/:slug` | Get single project |
| `POST` | `/api/projects` | Create project |
| `POST` | `/api/projects/:slug/image` | Upload cover image to R2 |
| `DELETE` | `/api/projects/:slug/image` | Remove image from R2 |

**Upload image example:**
```bash
curl -X POST https://api.yourdomain.com/api/projects/my-slug/image \
  -H "Content-Type: image/jpeg" \
  --data-binary @cover.jpg
```

---

## Database schema

### `leads`
| Column | Type | Notes |
|---|---|---|
| id | INTEGER PK | auto-increment |
| name | TEXT | required |
| email | TEXT | required |
| company | TEXT | optional |
| budget | TEXT | optional |
| message | TEXT | required |
| status | TEXT | `new` \| `read` \| `replied` |
| created_at | TEXT | ISO datetime, auto |

### `projects`
| Column | Type | Notes |
|---|---|---|
| id | INTEGER PK | auto-increment |
| slug | TEXT UNIQUE | URL-safe identifier |
| title | TEXT | |
| client | TEXT | |
| category | TEXT | SaaS, E-Commerce, Mobile… |
| description | TEXT | short (~150 chars) |
| long_description | TEXT | optional, full detail |
| tech_stack | TEXT | JSON array stored as string |
| image_key | TEXT | R2 object key |
| image_url | TEXT | public CDN URL |
| live_url | TEXT | optional |
| featured | INTEGER | boolean (0/1) |
| sort_order | INTEGER | display order |
| created_at | TEXT | ISO datetime, auto |

---

## Customisation checklist

- [ ] Replace `yourdomain.com` in `backend/wrangler.jsonc` routes and `backend/src/middleware/cors.ts`
- [ ] Set `R2_PUBLIC_URL` in `wrangler.jsonc` after enabling R2 public access
- [ ] Replace `YOUR_D1_DATABASE_ID_HERE` with the ID from `wrangler d1 create`
- [ ] Update studio name "Stratum" in `frontend/src/components/Nav.astro` and `Footer.astro`
- [ ] Update contact email in `frontend/src/components/Contact.astro`
- [ ] Add real project content via `POST /api/projects` + image upload
