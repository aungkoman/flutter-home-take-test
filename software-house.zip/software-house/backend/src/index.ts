import { Hono } from "hono";
import { logger } from "hono/logger";
import { secureHeaders } from "hono/secure-headers";
import { corsMiddleware } from "./middleware/cors";
import { leadsRouter } from "./routes/leads";
import { projectsRouter } from "./routes/projects";
import type { Env } from "./db/client";

const app = new Hono<{ Bindings: Env }>();

// ─── Global Middleware ───────────────────────────────────────────────────────
app.use("*", logger());
app.use("*", secureHeaders());
app.use("/api/*", corsMiddleware);

// ─── Health Check ────────────────────────────────────────────────────────────
app.get("/", (c) => c.json({ status: "ok", service: "software-house-api" }));

// ─── API Routes ──────────────────────────────────────────────────────────────
app.route("/api/leads", leadsRouter);
app.route("/api/projects", projectsRouter);

// ─── 404 Fallback ────────────────────────────────────────────────────────────
app.notFound((c) => c.json({ error: "Not found" }, 404));

// ─── Error Handler ───────────────────────────────────────────────────────────
app.onError((err, c) => {
  console.error(err);
  return c.json({ error: "Internal server error" }, 500);
});

export default app;
