import { cors } from "hono/cors";

// Allow requests from the Astro frontend and localhost during dev
export const corsMiddleware = cors({
  origin: (origin) => {
    const allowed = [
      "https://yourdomain.com",
      "https://www.yourdomain.com",
      "http://localhost:4321",   // Astro dev server
      "http://localhost:3000",
    ];
    return allowed.includes(origin) ? origin : null;
  },
  allowMethods: ["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
  allowHeaders: ["Content-Type", "Authorization"],
  maxAge: 86400,
});
