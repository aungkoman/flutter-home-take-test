import { sql } from "drizzle-orm";
import { integer, sqliteTable, text, real } from "drizzle-orm/sqlite-core";

// ─── Leads (Contact Form) ────────────────────────────────────────────────────

export const leads = sqliteTable("leads", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  email: text("email").notNull(),
  company: text("company"),
  budget: text("budget"),           // e.g. "$10k–$50k"
  message: text("message").notNull(),
  status: text("status").notNull().default("new"), // new | read | replied
  createdAt: text("created_at")
    .notNull()
    .default(sql`(datetime('now'))`),
});

// ─── Projects (Showcase) ─────────────────────────────────────────────────────

export const projects = sqliteTable("projects", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  client: text("client").notNull(),
  category: text("category").notNull(),   // e.g. "SaaS", "E-Commerce", "Mobile"
  description: text("description").notNull(),
  longDescription: text("long_description"),
  techStack: text("tech_stack").notNull(), // JSON array stored as text
  imageKey: text("image_key"),             // R2 object key for cover image
  imageUrl: text("image_url"),             // public CDN URL (cached after upload)
  liveUrl: text("live_url"),
  featured: integer("featured", { mode: "boolean" }).notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: text("created_at")
    .notNull()
    .default(sql`(datetime('now'))`),
});

// ─── Type Helpers ────────────────────────────────────────────────────────────

export type Lead = typeof leads.$inferSelect;
export type NewLead = typeof leads.$inferInsert;
export type Project = typeof projects.$inferSelect;
export type NewProject = typeof projects.$inferInsert;
