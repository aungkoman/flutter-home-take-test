import { drizzle } from "drizzle-orm/d1";
import * as schema from "./schema";

export type Env = {
  DB: D1Database;
  BUCKET: R2Bucket;
  ENVIRONMENT: string;
  R2_PUBLIC_URL: string;
};

export function createDb(env: Env) {
  return drizzle(env.DB, { schema });
}

export type Database = ReturnType<typeof createDb>;
