import { Hono } from "hono";
import { eq } from "drizzle-orm";
import { createDb, type Env } from "../db/client";
import { leads, type NewLead } from "../db/schema";

export const leadsRouter = new Hono<{ Bindings: Env }>();

// POST /api/leads — submit contact form
leadsRouter.post("/", async (c) => {
  const body = await c.req.json<Partial<NewLead>>();

  // Basic validation
  const { name, email, message } = body;
  if (!name?.trim() || !email?.trim() || !message?.trim()) {
    return c.json({ error: "name, email, and message are required" }, 400);
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return c.json({ error: "Invalid email address" }, 400);
  }

  const db = createDb(c.env);
  const [lead] = await db
    .insert(leads)
    .values({
      name: name.trim(),
      email: email.trim().toLowerCase(),
      company: body.company?.trim() ?? null,
      budget: body.budget?.trim() ?? null,
      message: message.trim(),
    })
    .returning();

  return c.json({ success: true, id: lead.id }, 201);
});

// GET /api/leads — list all leads (admin)
leadsRouter.get("/", async (c) => {
  const db = createDb(c.env);
  const all = await db
    .select()
    .from(leads)
    .orderBy(leads.createdAt);
  return c.json(all);
});

// PATCH /api/leads/:id/status — update lead status
leadsRouter.patch("/:id/status", async (c) => {
  const id = Number(c.req.param("id"));
  const { status } = await c.req.json<{ status: string }>();

  const validStatuses = ["new", "read", "replied"];
  if (!validStatuses.includes(status)) {
    return c.json({ error: `status must be one of: ${validStatuses.join(", ")}` }, 400);
  }

  const db = createDb(c.env);
  const [updated] = await db
    .update(leads)
    .set({ status })
    .where(eq(leads.id, id))
    .returning();

  if (!updated) return c.json({ error: "Lead not found" }, 404);
  return c.json(updated);
});
