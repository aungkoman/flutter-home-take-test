import { Hono } from "hono";
import { eq, desc } from "drizzle-orm";
import { createDb, type Env } from "../db/client";
import { projects, type NewProject } from "../db/schema";

export const projectsRouter = new Hono<{ Bindings: Env }>();

// GET /api/projects — list all projects (optionally filter featured)
projectsRouter.get("/", async (c) => {
  const featured = c.req.query("featured");
  const db = createDb(c.env);

  const rows = await db
    .select()
    .from(projects)
    .orderBy(projects.sortOrder);

  const filtered = featured === "true" ? rows.filter((p) => p.featured) : rows;

  // Parse techStack JSON for each row
  return c.json(
    filtered.map((p) => ({
      ...p,
      techStack: JSON.parse(p.techStack) as string[],
    }))
  );
});

// GET /api/projects/:slug
projectsRouter.get("/:slug", async (c) => {
  const slug = c.req.param("slug");
  const db = createDb(c.env);

  const [project] = await db
    .select()
    .from(projects)
    .where(eq(projects.slug, slug));

  if (!project) return c.json({ error: "Project not found" }, 404);

  return c.json({
    ...project,
    techStack: JSON.parse(project.techStack) as string[],
  });
});

// POST /api/projects — create project
projectsRouter.post("/", async (c) => {
  const body = await c.req.json<Partial<NewProject> & { techStack?: string[] }>();

  if (!body.slug || !body.title || !body.client || !body.category || !body.description) {
    return c.json({ error: "slug, title, client, category, description are required" }, 400);
  }

  const db = createDb(c.env);
  const [project] = await db
    .insert(projects)
    .values({
      ...body,
      techStack: JSON.stringify(body.techStack ?? []),
    } as NewProject)
    .returning();

  return c.json({ ...project, techStack: body.techStack ?? [] }, 201);
});

// POST /api/projects/:slug/image — upload cover image to R2
projectsRouter.post("/:slug/image", async (c) => {
  const slug = c.req.param("slug");
  const contentType = c.req.header("Content-Type") ?? "image/jpeg";

  if (!contentType.startsWith("image/")) {
    return c.json({ error: "Only image uploads are accepted" }, 400);
  }

  const db = createDb(c.env);
  const [project] = await db
    .select()
    .from(projects)
    .where(eq(projects.slug, slug));

  if (!project) return c.json({ error: "Project not found" }, 404);

  const key = `projects/${slug}/cover.${contentType.split("/")[1]}`;
  const body = await c.req.arrayBuffer();

  // Upload to R2
  await c.env.BUCKET.put(key, body, {
    httpMetadata: { contentType },
  });

  // Build public URL from env var
  const imageUrl = `${c.env.R2_PUBLIC_URL}/${key}`;

  // Persist key + URL to DB
  const [updated] = await db
    .update(projects)
    .set({ imageKey: key, imageUrl })
    .where(eq(projects.slug, slug))
    .returning();

  return c.json({ imageKey: key, imageUrl, project: updated });
});

// DELETE /api/projects/:slug/image — remove image from R2 and DB
projectsRouter.delete("/:slug/image", async (c) => {
  const slug = c.req.param("slug");
  const db = createDb(c.env);

  const [project] = await db
    .select()
    .from(projects)
    .where(eq(projects.slug, slug));

  if (!project) return c.json({ error: "Project not found" }, 404);
  if (!project.imageKey) return c.json({ error: "No image to delete" }, 404);

  await c.env.BUCKET.delete(project.imageKey);

  const [updated] = await db
    .update(projects)
    .set({ imageKey: null, imageUrl: null })
    .where(eq(projects.slug, slug))
    .returning();

  return c.json({ success: true, project: updated });
});
